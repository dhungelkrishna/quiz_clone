<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Button Div in php</title>
    <style>
        .body {
            padding: 0;
            margin: 0;
            box-sizing: border-box;
        }
        input[type='text'] {
            margin: 7px 15px;
            padding: 4px 5px;
            border: 1px solid green;
        }
    </style>
</head>
<body>
    <div class="f-question">
        <label for="Qn1">Qn 1. </label>
        <input type="text" name="Qn1" placeholder="Question 1">
    </div>
    
</body>
</html>